sap.ui.define(
    ["arvind/pp/penelope/matchange/Controller/baseController"],
    function(baseController){
        return baseController.extend("arvind.pp.penelope.matchange.Controller.App",{

            view2ID : '1',

            }

        );

    })  ;