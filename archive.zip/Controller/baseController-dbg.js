sap.ui.define(
    ["sap/ui/core/mvc/Controller"],
    function(Controller){
        return Controller.extend("arvind.pp.penelope.matchange.Controller.baseController",{
            oJson_creditlimit : "", 
            // new sap.ui.model.json.JSONModel(),
            reusecode: function(){

          
            }

        });

    })